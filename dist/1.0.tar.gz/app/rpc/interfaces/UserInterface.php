<?php

namespace app\rpc\interfaces;

interface UserInterface
{
    public function add($name);
}