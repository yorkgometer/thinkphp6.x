<?php

namespace app\home\controller\v2;

use app\BaseController;

class User extends BaseController
{
    public function getlist(){
        return "this is v1 home/v2/user/getlist";
    }
}