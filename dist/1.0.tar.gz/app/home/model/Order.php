<?php

namespace app\home\model;

use think\Model;

class Order extends Model
{

}